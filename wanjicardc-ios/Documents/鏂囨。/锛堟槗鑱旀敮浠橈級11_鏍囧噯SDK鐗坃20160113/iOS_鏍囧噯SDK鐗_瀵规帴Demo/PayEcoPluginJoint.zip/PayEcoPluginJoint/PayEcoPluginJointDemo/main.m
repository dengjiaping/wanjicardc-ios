//
//  main.m
//  PayEcoPluginJointDemo
//
//  Created by 詹海岛 on 15/1/19.
//  Copyright (c) 2015年 PayEco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
